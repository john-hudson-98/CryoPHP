<?php

    namespace Cryo\Mvc;

    interface Controller {
        
    }

?>