<?php

    namespace App\Controllers;

    @Controller 
    @ReactApp( app_name="portfolio" , local_url="http://localhost:3000")
    @ReactRoute( match_type="starts_with" , value="/" , mapsTo="/")
    class Portfolio {
        
    }

?>